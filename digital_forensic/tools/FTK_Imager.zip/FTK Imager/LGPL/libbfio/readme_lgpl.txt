libbfio is licensed under LGPL; here is a link to the source code: 
https://github.com/libyal/libbfio/releases/download/20180910/libbfio-alpha-20180910.tar.gz 
