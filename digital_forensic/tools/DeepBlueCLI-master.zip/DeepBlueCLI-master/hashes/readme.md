Placeholder for upcoming Virustotal submission script via Sysmon logs/hashes.
