s_readline();
s_string("TRUN ");
s_string_variable("0");

generic_send_tcp 192.168.130.139 9999 ScriptBOFindows/stats.spk 0 0


Same for others command a part of TRUN
