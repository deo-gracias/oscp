﻿Function Invoke-PTTSweep {
    [cmdletbinding()]
    param (
        [parameter(mandatory = $true, ValueFromPipeline = $true)]
        $Session
    )
    Begin {
        $Flagged = @()
        $Klist = klist
        $Current = ((($klist) -split 'Current LogonId is')[2] -split ':')[1]
    }
    Process {
        $LogonId = $($Session.LogonId)
        $Expected = $(($Session.User).Split('\')[1]).Trim()
        Try {
            if ($LogonId -eq $Current) {
                $Actual = $((((klist | sls '^#0') -split 'Client: ')[1] -split '@')[0]).Trim() 
            }
            else {           
                $Actual = $((((klist -li $LogonId  | sls '^#0') -split 'Client: ')[1] -split '@')[0]).Trim()
            }  
        }
        Catch {
            if ($_ -like "*Error calling API*") {
                $_ | Out-null
            }
        }
        if ($Expected -ne $Actual) {
            if (!$Actual -ne "$env:computername$") {
		$Flagged += [PSCustomObject]@{'LogonId' = $LogonId; 'SessionUser' = $Expected; 'TGTUser' = $Actual}
            }
        }     
    }
    End {
        return $Flagged
    }
}