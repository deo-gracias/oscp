﻿$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational">
    <Select Path="Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational">
     *[System[(EventID=1149)]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $TargetUserName = $XML.Event.UserData.EventXML.Param1
   $Domain = $XML.Event.UserData.EventXML.Param2
   $Source = $XML.Event.UserData.EventXML.Param3
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'Domain' = $Domain; 'Source' = $Source }
}