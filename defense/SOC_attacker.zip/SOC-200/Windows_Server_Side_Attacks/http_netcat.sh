#!/usr/bin/env zsh
trap 'kill $BGPID; exit' INT
python3 -m http.server 8000 &
BGPID=$!
nc -vnlp 4444
kill $BGPID
