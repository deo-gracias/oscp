import sys

def usage():
    print("Usage: "   + sys.argv[0] + " [date]")
    print("Usage: "   + sys.argv[0] + " 12.02.2021")
    sys.exit()

def generate_domain(year: int, month: int, day: int) -> str:
    domain = ""

    for i in range(0x10):
        year = ((year ^ 8 * year) >> 11) ^ ((year & 0xFFFFFFF0) << 17)
        month = ((month ^ 4 * month) >> 25) ^ 16 * (month & 0xFFFFFFF8)
        day = ((day ^ (day << 13)) >> 19) ^ ((day & 0xFFFFFFFE) << 12)
        domain += chr(((year ^ month ^ day) % 25) + 97)

    print(domain + ".com")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        date    = sys.argv[1]
        y,m,d = date.split('.')
        generate_domain(int(y),int(m),int(d))
    else:
        usage()
