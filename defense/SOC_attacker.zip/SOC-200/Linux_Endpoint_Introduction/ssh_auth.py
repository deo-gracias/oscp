import paramiko
import sys

nbytes = 4096
port = 22
username = 'offsec'

def usage():
    print("Usage: " + sys.argv[0] + " [remote_host] [valid|invalid]")
    sys.exit()

if len(sys.argv) > 2:
    hostname = sys.argv[1]
    login = sys.argv[2]
else:
    usage()

if login == "valid":
    password = 'lab'
elif login == "invalid":
    password = "wrongpass"
else:
    usage()

client = paramiko.Transport((hostname, port))

try:
    client.connect(username=username, password=password)
    print("[*] - Performed a valid authentication attempt - Check the remote host logs")
except(paramiko.ssh_exception.AuthenticationException):
    print("[*] - Performed an invalid authentication attempt - Check the remote host logs")

client.close()
