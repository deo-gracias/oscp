#!/usr/bin/env python

import re
import os.path

centos_ssh_log_file_path = "/var/log/secure"
ubuntu_shh_log_file_path = "/var/log/auth.log"

ssh_log_files = [centos_ssh_log_file_path,ubuntu_shh_log_file_path]

regex = 'sshd\[.*\]'
for log_file in ssh_log_files:
	if os.path.isfile(log_file) :
		with open(log_file, "r") as file:
		    for line in file:
		        for match in re.finditer(regex, line, re.S):
		            print(line,end = '')
