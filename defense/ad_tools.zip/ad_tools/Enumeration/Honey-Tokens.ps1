Function Get-GuidName ($Guid) {
    Begin {
        $ObjectTable = @{
            '%{a11236c4-e6ae-4dc7-ad58-92b6b6b5f83d}' = 'HoneySrv01'
            '%{a1a88fa6-e570-4520-9b21-6bad8483979b}' = 'HoneyPC01'
            '%{6e1648e7-b100-4bdf-b497-7061e8d7a068}' = 'HoneyUser01'
            '%{74215987-5fa5-4e36-b4d2-c9fdc5fca747}' = 'HoneySvc01'
            '%{c2e86461-de97-4ef5-881c-e6ccfb97df5d}' = 'HoneySecGroup01'
            '%{02f71039-cf2c-47a8-aeeb-ff257851f149}' = 'HoneyDistGroup01'
        }
    }
    Process {
        $Value = $ObjectTable[$Guid]
        If (!$Value) {
            $Value = $Guid
        }
    }
    End {
        return $Value
    }
}

Function Get-AccessName ($AccessMask) {
    Begin {
        $AccessTable = @{
            '0x10' = 'Read Property'
            '0x20000' = 'READ_CONTROL'
        }
    }
    Process {
        $Value = $AccessTable[$AccessMask]
        If (!$Value) {
            $Value = $AccessMask
        }
    }
    End {
        return $Value
    }
}

$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
     *[System[(EventID=4662)]] 
     and 
     *[EventData[(Data[@Name='OperationType']='Object Access')]]
     and
     *[EventData[Data[@Name='ObjectName'] and (Data='%{02f71039-cf2c-47a8-aeeb-ff257851f149}' or 
     Data='%{a1a88fa6-e570-4520-9b21-6bad8483979b}' or Data='%{6e1648e7-b100-4bdf-b497-7061e8d7a068}' or
     Data='%{74215987-5fa5-4e36-b4d2-c9fdc5fca747}' or Data='%{c2e86461-de97-4ef5-881c-e6ccfb97df5d}' or
     Data='%{02f71039-cf2c-47a8-aeeb-ff257851f149}')]]
   </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $SubjectUserName = $XML.Event.EventData.Data[1].'#text'
   $ObjectName = Get-GuidName $($XML.Event.EventData.Data[6].'#text')
   $AccessMask = Get-AccessName $($XML.Event.EventData.Data[10].'#text')
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'SubjectUserName' = $SubjectUserName; 'ObjectName' = $ObjectName; 'AccessMask' = $AccessMask }
}