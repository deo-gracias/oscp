Function Get-GuidName ($Guid) {
    Begin {
        $ObjectTable = @{
            '%{0ca1d341-b9ee-4d46-ab3b-3a2732aa4b51}' = 'Domain Admins'
        }
    }
    Process {
        $Value = $ObjectTable[$Guid]
        If (!$Value) {
            $Value = $Guid
        }
    }
    End {
        return $Value
    }
}

Function Get-AccessName ($AccessMask) {
    Begin {
        $AccessTable = @{
            '0x10' = 'Read Property'
            '0x20000' = 'READ_CONTROL'
        }
    }
    Process {
        $Value = $AccessTable[$AccessMask]
        If (!$Value) {
            $Value = $AccessMask
        }
    }
    End {
        return $Value
    }
}

$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
     *[System[(EventID=4662)]] 
     and 
     *[EventData[(Data[@Name='SubjectUserSid']='S-1-5-21-2154860315-1826001137-329834519-1107')]]
     and
     *[EventData[(Data[@Name='ObjectName']='%{0ca1d341-b9ee-4d46-ab3b-3a2732aa4b51}')]]
     and
     *[EventData[(Data[@Name='OperationType']='Object Access')]]
   </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $SubjectUserName = $XML.Event.EventData.Data[1].'#text'
   $ObjectName = Get-GuidName $($XML.Event.EventData.Data[6].'#text')
   $AccessMask = Get-AccessName $($XML.Event.EventData.Data[10].'#text')
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'SubjectUserName' = $SubjectUserName; 'ObjectName' = $ObjectName; 'AccessMask' = $AccessMask }
}