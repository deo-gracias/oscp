Function Get-KerberosSettings {
    Begin {
        [xml]$XML = Get-GPOReport -Name 'Default Domain Policy' -ReportType xml
    }
    Process {
        $Kerberos = $XML.GPO.Computer.ExtensionData.Extension.Account | Where-Object { $_.Type -eq 'Kerberos' }
    }
    End {
        return [PSCustomObject]@{'MaxClockSkew' = $Kerberos[0].SettingNumber; 'MaxRenewAge' = $Kerberos[1].SettingNumber; 
            'MaxServiceAge' = $Kerberos[2].SettingNumber; 'MaxTicketAge' = $Kerberos[3].SettingNumber; 'TicketValidateClient' = $Kerberos[4].SettingBoolean
        }
    }
}