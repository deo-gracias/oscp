Function Get-ChangeType ([System.String]$EventId) {
    Begin {
        $ChangeTable = @{
            '4728' = 'A member was added to a security-enabled global group.'
            '4729' = 'A member was removed from a security-enabled global group.'
            '4732' = 'A member was added to a security-enabled local group.'
            '4733' = 'A member was removed from a security-enabled local group.'
            '4756' = 'A member was added to a security-enabled universal group.'
            '4757' = 'A member was removed from a security-enabled universal group.'
        }
    }
    Process {
        $Value = $ChangeTable[$EventId]
        If (!$Value) {
            $Value = $EventId
        }
    }
    End {
        return $Value
    }
}

$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">*[System[(EventID=4728 or EventID=4729 or EventID=4732 or EventID=4733 or EventID=4756 or EventID=4757)]]
    and
    *[EventData[Data[@Name='TargetUserName'] and (Data='Domain Admins' or Data='Administrators' or Data='Enterprise Admins')]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $EventId = $XML.Event.System.EventID
   $MemberName = $XML.Event.EventData.Data[0].'#text'
   $GroupName = $XML.Event.EventData.Data[2].'#text'
   $SubjectUserName = $XML.Event.EventData.Data[6].'#text'
   $ChangeType = Get-ChangeType -EventId $EventId
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'MemberName' = $MemberName; 'GroupName' = $GroupName; 'SubjectUserName' = $SubjectUserName; 'ChangeType' = "($EventID) $ChangeType" }
}