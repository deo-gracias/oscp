Function Invoke-GoldenSweep {
    [cmdletbinding()]
    param (
        [parameter(mandatory = $true, ValueFromPipeline = $true)]
        $Ticket
    )
    Process {
        # Time Beacons
        $StartTime = ($Ticket.StartTime -split ' ')[0]
        $EndTime = ($Ticket.EndTime -split ' ')[0]
        $RenewTime = ($Ticket.RenewTime -split ' ')[0]

        if ((New-TimeSpan -Start $StartTime -End $EndTime).Days -gt 10) {
            $Flagged = $Ticket
        }

        if ($RenewTime -ne 0) {
            if ((New-TimeSpan -Start $StartTime -End $RenewTime).Days -gt 7) {
                $Flagged = $Ticket
            }
        }
        
        # Encryption Beacons
        $EncryptionType = $Ticket.EncryptionType  
        if ($EncryptionType -eq 'RSADSI RC4-HMAC(NT)') {
            $Flagged = $Ticket
        }
    }
    End {
        return $Flagged
    }
}