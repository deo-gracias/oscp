Function Get-ChangeType ([System.String]$EventId) {
    Begin {
        $ChangeTable = @{
            '4720' = 'A user account was created.'
            '4722' = 'A user account was enabled.'
            '4723' = 'An attempt was made to change an account''s password.'
            '4724' = 'An attempt was made to reset an account''s password.'
            '4738' = 'A user account was changed.'
            '4740' = 'A user account was locked out.'
            '4765' = 'SID History was added to an account.'
            '4766' = 'An attempt to add SID History to an account failed.'
            '4767' = 'A user account was unlocked.'
            '4780' = 'The ACL was set on accounts which are members of administrators groups.'
            '4781' = 'The name of an account was changed.'
            '4794' = 'An attempt was made to set the Directory Services Restore Mode administrator password.'
            '4798' = 'A user''s local group membership was enumerated.'
            '5376' = 'Credential Manager credentials were backed up.'
            '5377' = 'Credential Manager credentials were restored from a backup.'
            '5379' = 'Credential Manager credentials were read'
        }
    }
    Process {
        $Value = $ChangeTable[$EventId]
        If (!$Value) {
            $Value = $EventId
        }
    }
    End {
        return $Value
    }
}

$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 13824]]
    and 
    *[EventData[Data[@Name='SubjectUserName'] and (Data='dadmin')]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $TargetUserName = $XML.Event.EventData.Data[1].'#text'
   $EventId = $XML.Event.System.EventID
   $SubjectUserName = ($XML.Event.EventData.Data | Where {$_.Name -eq 'SubjectUserName'}) | Select -ExpandProperty '#text'
   $TargetUserName = ($XML.Event.EventData.Data | Where {$_.Name -eq 'TargetUserName'}) | Select -ExpandProperty '#text'
   $ChangeType = Get-ChangeType -EventId $EventId
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'SubjectUserName' = $SubjectUserName; 'TargetUserName' = $TargetUserName; 'ChangeType' = "($EventID) $ChangeType" }
}