Function Get-LogonIds {
    Begin {
        $Klist = klist sessions
    }
    Process {
        $Sessions = $Klist | Where-Object { $_ -like '* Session*' } | ForEach-Object { (($_ -split ' ')[3]).substring(2) }
    }
    End {
        return $Sessions
    }
}