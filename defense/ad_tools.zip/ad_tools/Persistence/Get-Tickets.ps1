Function Get-Tickets {
    [cmdletbinding()]
    param (
        [parameter(mandatory = $false, ValueFromPipeline = $true)]
        [System.String]$LogonId
    )
    Begin {
        $CachedTickets = @()
        $Klist = klist
        $Current = ((($klist) -split 'Current LogonId is')[2] -split ':')[1]
    }
    Process {
        try {
            if ($LogonId -eq $Current -or $LogonId -eq '') {
                $Klist = klist
                $LogonId = $Current
            }
            else {           
                $Klist = klist -li $LogonId
            }
            
            $Tickets = 5..$Klist.count | ForEach-Object { $Klist[$_] } | Where-Object { $_ }
            if ($Klist -notcontains 'Cached Tickets: (0)') {
                0..$(($Tickets | Select-String "^#\d>").Count - 1) | ForEach-Object {
                    $Index = $_ * 10
                    $Properties = [ordered]@{
                        'LogonId'        = $LogonId
                        'Ticket'         = $_
                        'Client'         = $($Tickets[0 + $Index] -split ':')[1].Trim()
                        'Server'         = $($Tickets[1 + $Index] -split ':')[1].Trim()
                        'EncryptionType' = $($Tickets[2 + $Index] -split ':')[1].Trim()
                        'TicketFlags'    = $($Tickets[3 + $Index] -split 'Ticket Flags')[1].Trim()
                        'StartTime'      = $($Tickets[4 + $Index] -split 'Start Time:')[1].Trim()
                        'EndTime'        = $($Tickets[5 + $Index] -split 'End Time:')[1].Trim()
                        'RenewTime'      = $($Tickets[6 + $Index] -split 'Renew Time:')[1].Trim()
                        'SessionKeyType' = $($Tickets[7 + $Index] -split ':')[1].Trim()
                        'CacheFlags'     = $($Tickets[8 + $Index] -split ':')[1].Trim()
                        'KdcCalled'      = $($Tickets[9 + $Index] -split ':')[1].Trim()
                    }
                    
                    if ($Properties) {
                        $CachedTickets += New-Object -TypeName PSObject -Property $Properties
                    }
                }
            }
        }
        catch {
            if ($_ -like "*Error calling API*") {
                $_ | Out-null
            }
        }
    }
    End {
        return $CachedTickets
    }
}