﻿$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
    *[System[(EventID=4624)]]
    and 
    *[EventData[Data[@Name='LogonType'] and (Data='3')]]
    and 
    *[EventData[Data[@Name='AuthenticationPackageName'] and (Data='NTLM')]]
    </Select>
  </Query>
  <Query Id="1" Path="System">
    <Select Path="System">
    *[System[(EventID=7045)]]
    and
    *[EventData[Data[@Name='ServiceName'] and (Data='PSEXESVC')]]
    or
    *[System[(EventID=7036)]]
    and
    *[EventData[Data[@Name='param1'] and (Data='PSEXESVC')]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
  [xml]$XML = $L.toXml()
  $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
  $EventId = $XML.Event.System.EventID.'#text'
  If (!$EventId) {
    $EventId = $XML.Event.System.EventID
  }
   
  Switch ($EventId) {
    '7036' {
      $ServiceName = $XML.Event.EventData.Data[0].'#text'
      $ServiceStatus = $XML.Event.EventData.Data[1].'#text'
      $Details = "Service $ServiceName is $ServiceStatus"
    }
    '7045' {
      $ServiceName = $XML.Event.EventData.Data[0].'#text'
      $ServiceBinary = $XML.Event.EventData.Data[1].'#text'
      $ServiceAccount = $XML.Event.EventData.Data[4].'#text'
      $Details = "Service $ServiceName installed using $ServiceBinary as $ServiceAccount"
    }
    '4624' {
      $TargetUserName = $XML.Event.EventData.Data[5].'#text'
      $WorkstationName = $XML.Event.EventData.Data[11].'#text'
      $Details = "$TargetUsername logged in remotely from $WorkstationName"
    }
    
  }
  [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'Event' = $EventId; 'Details' = $Details; ; }
}