﻿$CurrentDomain = "LDAP://"+([ADSI]"").DistinguishedName

$username = "jane"
$password = "notthisone"
for($i = 0; $i -lt 10; $i++)
{
    $dom = New-Object System.DirectoryServices.DirectoryEntry($CurrentDomain, $username, $password)
    $res = $dom.Name
}

$username = "ben"
$password = "notthisone"
for($i = 0; $i -lt 2; $i++)
{
    $dom = New-Object System.DirectoryServices.DirectoryEntry($CurrentDomain, $username, $password)
    $res = $dom.Name
}
