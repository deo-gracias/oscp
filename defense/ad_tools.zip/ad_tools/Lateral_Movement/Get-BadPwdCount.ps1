﻿function Get-BadPwdCount {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $false, ParameterSetName = 'List')]
        [switch]$List,
        [Parameter(Mandatory = $false, ParameterSetName = 'List')]
        [string]$Username,
        [Parameter(Mandatory = $false, ParameterSetName = 'Statistics')]
        [string]$Expected
    )
    Begin { 
        # Only query against the PDC to ensure our results are accurate
        $Domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        $PDC = $Domain.PdcRoleOwner
        $SearchRoot = "LDAP://{0}/DC={1}" -f $PDC,$Domain.Name.Replace('.',',DC=')
        $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchRoot)

        # Only pull down the two attributes we need
        $Searcher.PropertiesToLoad.Add("sAMAccountName") | Out-Null
        $Searcher.PropertiesToLoad.Add("badPwdCount") | Out-Null
        $Searcher.PageSize = 1000

        # Targeted user or every enabled user account
        If ($Username) {
            $Searcher.Filter = "(sAMAccountName=$Username)"
        } else {
            $Searcher.Filter = "(&(objectCategory=person)(objectClass=user)(!userAccountControl:1.2.840.113556.1.4.803:=2))"
        }
        $Users = $Searcher.FindAll()
    }
    Process {       
        # Output all, or a designated sAMAccountName and their badPwdCount value
        if ($List) {
            $Results = $Users | Where-Object { $_.Properties.badpwdcount -gt 0 } | ForEach-Object {
                [PSCustomObject]@{'SamAccountName' = $($_.Properties.samaccountname); 'BadPwdCount' = $($_.Properties.badpwdcount) }
            }
        }

        # Output percentage of all enabled accounts that have a badPwdCount value greater than 0
        if (!$List) {
            $BadPwdCount = $($Users | Where-Object { $_.Properties.badpwdcount -gt 0 }).Count
            $Actual = [math]::Round($BadPwdCount / $Users.Count * 100, 2)
            $Results = [PSCustomObject]@{'TotalUsers' = $Users.Count; 'Expected' = "$Expected%"; 'Actual' = "$Actual%" }
        }
    }
    End { 
        return $Results
    }
}