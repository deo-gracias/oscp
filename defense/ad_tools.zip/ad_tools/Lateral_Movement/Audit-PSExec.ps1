﻿$FilterXML = @'
<QueryList>
  <Query Id="0" Path="System">
    <Select Path="System">
    *[System[(EventID=7045)]]
    and
    *[EventData[Data[@Name='ServiceName'] and (Data='PSEXESVC')]]
    or
    *[System[(EventID=7036)]]
    and
    *[EventData[Data[@Name='param1'] and (Data='PSEXESVC')]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
  [xml]$XML = $L.toXml()
  $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
  $EventId = $XML.Event.System.EventID.'#text'
  If ($EventId -eq '7045') {
    $ServiceName = $XML.Event.EventData.Data[0].'#text'
    $ServiceBinary = $XML.Event.EventData.Data[1].'#text'
    $ServiceAccount = $XML.Event.EventData.Data[4].'#text'
    $Details = "Service $ServiceName installed using $ServiceBinary as $ServiceAccount"
  }
  Else {
    $ServiceName = $XML.Event.EventData.Data[0].'#text'
    $ServiceStatus = $XML.Event.EventData.Data[1].'#text'
    $Details = "Service $ServiceName is $ServiceStatus"
  }
   
  [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'Event' = $EventId; 'Details' = $Details; ; }
}