﻿$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">*[System[(EventID=4624)]]
    and 
    *[EventData[Data[@Name='LogonType'] and (Data='3')]]
    and 
    *[EventData[Data[@Name='AuthenticationPackageName'] and (Data='NTLM')]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $TargetUserName = $XML.Event.EventData.Data[5].'#text'
   $WorkstationName = $XML.Event.EventData.Data[11].'#text'
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'WorkstationName' = $WorkstationName;}
}