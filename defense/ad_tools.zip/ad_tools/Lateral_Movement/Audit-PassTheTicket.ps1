﻿Function Get-TGT {
  Begin {
    $TGT = @()
    $FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
     *[System[band(Keywords,9007199254740992) and (EventID=4768)]]
   </Select>
  </Query>
</QueryList>
'@
  }
  Process {
    $Logs = Get-WinEvent -FilterXml $FilterXML
    ForEach ($L in $Logs) {
      [xml]$XML = $L.toXml()
      $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
      $TargetUserName = $XML.Event.EventData.Data[0].'#text'
      $IPAddress = $($XML.Event.EventData.Data[9].'#text')
      If ($IPAddress -eq '::1') {
        $IPAddress = $(Test-Connection -ComputerName $env:COMPUTERNAME -Count 1 | Select -ExpandProperty IPv4Address).IPAddressToString
      }
      else {
        $IPAddress = $IPAddress.split('::ffff:')[-1]
      }
      $TGT += [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'IPAddress' = $IPAddress }
    }
  }
  End {
    return $TGT
  }
}
Function Get-TGS {
  Begin {
    $TGS = @()
    $FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
     *[System[band(Keywords,9007199254740992) and (EventID=4769)]]
   </Select>
  </Query>
</QueryList>
'@
  }
  Process {
    $Logs = Get-WinEvent -FilterXml $FilterXML
    ForEach ($L in $Logs) {
      [xml]$XML = $L.toXml()
      $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
      $TargetUserName = $($XML.Event.EventData.Data[0].'#text' -split '@')[0]
      $IPAddress = $($XML.Event.EventData.Data[6].'#text')
      If ($IPAddress -eq '::1') {
        $IPAddress = $(Test-Connection -ComputerName $env:COMPUTERNAME -Count 1 | Select -ExpandProperty IPv4Address).IPAddressToString
      }
      else {
        $IPAddress = $IPAddress.split('::ffff:')[-1]
      }
      $TGS += [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'IPAddress' = $IPAddress }
    }
  }
  end {
    return $TGS
  }
}

$TGT = Get-TGT
$TGS = Get-TGS

ForEach ($T in $TGS) {
    $Valid = $TGT | Where-Object {$_.TargetUserName -eq $($T.TargetUserName) -and $_.IPAddress -eq $($T.IPAddress)}
    If (!$Valid) {
        $T
    }
}