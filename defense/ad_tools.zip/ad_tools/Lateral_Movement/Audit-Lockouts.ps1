﻿$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
    *[System[(EventID=4740)]]
    </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
  [xml]$XML = $L.toXml()
  $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
  $TargetUserName = $XML.Event.EventData.Data[0].'#text'
  $CallerWorkstation = $XML.Event.EventData.Data[1].'#text'
  $AnsweringDC = $XML.Event.EventData.Data[4].'#text'
  [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'CallerWorkstation' = $CallerWorkstation; 'AnsweringDC' = $AnsweringDC
  }
}