﻿Function Get-FailureReason ($StatusCode) {
    Begin {
        $StatusTable = @{
            '0xC000006A' = 'User logon with misspelled or bad password'
            '0XC000006D' = 'The cause is either a bad username or authentication information'
        }
    }
    Process {
        $Value = $StatusTable[$StatusCode]
        If (!$Value) {
            $Value = $StatusCode
        }
    }
    End {
        return $Value
    }
}
    
$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
    *[System[(EventID=4625)]]
    and
    *[EventData[Data[@Name='TargetUserName'] and (Data='jim')]]
    </Select>
  </Query>
</QueryList>
'@
    
$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
    [xml]$XML = $L.toXml()
    $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
    $TargetUserName = $XML.Event.EventData.Data[5].'#text'    
    $FailureReason = Get-FailureReason -StatusCode $($XML.Event.EventData.Data[9].'#text')
    $LogonType = $XML.Event.EventData.Data[10].'#text'
    $WorkstationName = $XML.Event.EventData.Data[13].'#text'
    [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'FailureReason' = $FailureReason; 'LogonType' = $LogonType ; 'WorkstationName' = $WorkstationName 
    }
}
