﻿Function Get-TicketEncryption ($Type) {
    Begin {
        $TypeTable = @{
            '0x17' = 'RC4-HMAC'
            '0x18' = 'RC4-HMAC-EXP'
        }
    }
    Process {
        $Value = $TypeTable[$Type]
        If (!$Value) {
            $Value = $Type
        }
    }
    End {
        return $Value
    }
}

$FilterXML = @'
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">
     *[System[(EventID=4769)]] 
     and
     *[EventData[Data[@Name='TicketEncryptionType'] and (Data='0x17' or Data='0x18')]]
   </Select>
  </Query>
</QueryList>
'@

$Logs = Get-WinEvent -FilterXml $FilterXML
ForEach ($L in $Logs) {
   [xml]$XML = $L.toXml()
   $TimeStamp = $XML.Event.System.TimeCreated.SystemTime
   $TargetUserName = $XML.Event.EventData.Data[0].'#text'
   $ServiceName = $XML.Event.EventData.Data[2].'#text'
   $TicketEncryptionType = Get-TicketEncryption -Type $($XML.Event.EventData.Data[5].'#text')
   $IPAddress = $XML.Event.EventData.Data[6].'#text'
   [PSCustomObject]@{'TimeStamp' = $TimeStamp; 'TargetUserName' = $TargetUserName; 'ServiceName' = $ServiceName; 'TicketEncryptionType' = $TicketEncryptionType; 'IPAddress' = $IPAddress }
}